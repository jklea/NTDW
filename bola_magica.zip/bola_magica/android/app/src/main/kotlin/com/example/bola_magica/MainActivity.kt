package com.example.bola_magica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
