package com.example.xilofone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
