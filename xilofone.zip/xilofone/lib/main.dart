import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(XylophoneApp());

class XylophoneApp extends StatelessWidget {
  static AudioCache player = AudioCache();
  

  Expanded criaBotao(Color cor, int num){
    return Expanded(
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: cor,
        ),
        onPressed: (){
          player.play('note1$num.wav');
        },
        child: Text(''),
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              criaBotao(Colors.red, 1),
              criaBotao(Colors.orange, 2),
              criaBotao(Colors.yellow, 3),
              criaBotao(Colors.green, 4),
              criaBotao(Colors.teal, 5),
              criaBotao(Colors.blue, 6),
              criaBotao(Colors.purple, 7)
              
            ],
          ),
        ),
      ),
    );
  }
}
