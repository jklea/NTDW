class Cena {
  String descricaoCena;
  List<String> acoesDisponiveis;
  List<int> proximasCenas;
  Cena(this.descricaoCena, this.acoesDisponiveis, this.proximasCenas);
}
