import 'cena.dart';

class Jogo {
  int _cenaAtual = 0;
  int getcenaAtual() => _cenaAtual;

  List<Cena> _cenas = [
    Cena(
        'Você acorda com o som dos pássaros. A última coisa que você se lembra é de ter sido sequestrado. Você resolve olhar ao redor para descobrir mais sobre a sua situação e percebe que está dentro de um quarto. Na parede, há quadros com fotos de algumas pessoas. Na cômoda ao lado da cama em que você está, há um telefone.',
        ['Pegar o telefone.', 'Olhar os quadros.'],
        [1, 2]),
    Cena(
        'Você olha o telefone. Homens armados entram no quarto, vêem você com o telefone na mão e atiram em você. Você morreu.',
        ['Voltar', 'acao2'],
        [0, 0]),
    Cena(
        'Você olha os quadros. Em um deles, há uma foto sua sorrindo ao lado de um prédio segurando uma placa que diz: vencedor número 1 do sorteio Grande Prêmio. Nesse momento, homens armados entram no quarto e te arrastam de lá. Você é amarrado e jogado na caçamba de uma caminhonete. Os homens ligam o veículo e o carro começa a se locomover.',
        ['Pular da caminhonete.', 'Esperar a caminhonete parar de andar.'],
        [3, 5]),
    Cena(
        'Você pula da caminhonete. Os homens se enfurecem e atiram em você. Você morre por perda excessiva de sangue.',
        ['Voltar', 'acao2'],
        [0, 0]),
    Cena(
        'Você resolve esperar a caminhonete parar de se locomover. Logo, o automóvel para em um posto de gasolina e os seus sequestradores descem do carro e entram na conveniência. Você foi deixado sozinho na caminhonete. ',
        ['Tentar fugir.', 'Gritar por socorro.'],
        [5, 8]),
    Cena(
        'Você desce da caminhonete e corre para longe de seus sequestradores. Você vê uma caçamba de lixo e mais a frente, uma cabine telefônica.',
        ['Se esconder na caçamba de lixo.', 'Tentar ligar para a polícia.'],
        [6, 7]),
    Cena(
        'Você se esconde na caçamba de lixo. Você ouve sons de tiros. Depois de um tempo, tudo fica silencioso. Você olha fora da caçamba de lixo e percebe que não tem ninguém à sua volta. Você corre para a cabine telefônica e liga para a polícia. Você é resgatado.',
        ['Voltar', 'acao2'],
        [0, 0]),
    Cena(
        'Você corre para a cabine telefônica. Os sequestradores percebem que você fugiu e atiram em você. Você morreu.',
        ['Voltar', 'acao2'],
        [0, 0]),
    Cena(
        'Você grita por socorro. Os sequestradores percebem a gritaria, voltam correndo para o carro e te nocauteiam. Você morre por hemorragia cerebral.',
        ['Voltar', 'acao2'],
        [0, 0])
  ];

  String pegarDescricao() {
    return _cenas[_cenaAtual].descricaoCena;
  }

  List<String> pegarAcoes() {
    return _cenas[_cenaAtual].acoesDisponiveis;
  }

  List<int> pegarProximasCenas() {
    return _cenas[_cenaAtual].proximasCenas;
  }

  void reiniciar() {
    _cenaAtual = 0;
  }

  void nextCena(acao) {
    _cenaAtual = acao;
  }
}
