import 'package:flutter/material.dart';
import 'jogo.dart';

void main() => runApp(JogoPage());
bool visibilidade = true;

class JogoPage extends StatefulWidget {
  @override
  _JogoPageState createState() => _JogoPageState();
}

class _JogoPageState extends State<JogoPage> {
  Jogo jogo = Jogo();

  Expanded criaBotao(
      Color cor, int numAcao, String textAcao, VoidCallback cb, bool visi) {
    return visi == true
        ? Expanded(
            flex: 1,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextButton(
                style: TextButton.styleFrom(
                  backgroundColor: cor,
                ),
                onPressed: cb,
                child: Text(textAcao),
              ),
            ),
          )
        : Expanded(
            flex: 1,
            child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Visibility(
                    visible: false,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        backgroundColor: cor,
                      ),
                      onPressed: cb,
                      child: Text(''),
                    ))),
          );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      backgroundColor: Colors.grey,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                flex: 5,
                child: Center(child: Text(jogo.pegarDescricao())),
              ),
              criaBotao(Colors.red, jogo.pegarProximasCenas()[0],
                  jogo.pegarAcoes()[0], () {
                jogo.nextCena(jogo.pegarProximasCenas()[0]);
                setState(() {});
              }, visibilidade = true),
              criaBotao(Colors.red, jogo.pegarProximasCenas()[1],
                  jogo.pegarAcoes()[1], () {
                jogo.nextCena(jogo.pegarProximasCenas()[1]);
                setState(() {});
              },
                  jogo.pegarProximasCenas()[1] == 0
                      ? visibilidade = false
                      : visibilidade = true),
            ],
          ),
        ),
      ),
    ));
  }
}
