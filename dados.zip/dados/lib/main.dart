import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(
      MaterialApp(
        home: DadoPage(),
        debugShowCheckedModeBanner: false,
      ),
);

class DadoPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
          backgroundColor: Colors.red,
          appBar: AppBar(
            title: Text('Dados virtuais'),
            backgroundColor: Colors.red,
          ),
          body: Dado(),
      );
  }
}

class Dado extends StatefulWidget {
  @override
  _DadoState createState() => _DadoState();
}

class _DadoState extends State<Dado> {
  int nrDado1 = 1;
  int nrDado2 = 2;

  void rolarDados(){
    setState(() {
      nrDado1 = Random().nextInt(6)+1;
      nrDado2 = Random().nextInt(6)+1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 1,
            child: TextButton(
              onPressed: (){
                rolarDados();
              },
              child: Image.asset('Images/dado$nrDado1.png'),

            ),
          ),
          Expanded(
            flex: 1,
            child: TextButton(
              onPressed: (){
                rolarDados();
              },
              child: Image.asset('Images/dado$nrDado2.png'),
            ),
          ),
        ],
      )
      
      
    ); 
  }
}