package com.example.dados

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
